<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'hPt7qgK7t1gutuGvbpKRtw');
define('CONSUMER_SECRET', 'NGQu97Brv8rH0y6JAssay6SHxtnjbTBR6CXPUm6E');
define('OAUTH_CALLBACK', 'localhost.socialnuke.com/dashboard.html');
